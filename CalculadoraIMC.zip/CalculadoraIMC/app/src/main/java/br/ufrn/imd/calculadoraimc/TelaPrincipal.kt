package br.ufrn.imd.calculadoraimc

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_tela_principal.*

class TelaPrincipal : AppCompatActivity() {

    private val ALTERAR_PESO = 1
    private val ALTERAR_ALTURA = 2
    private val VALOR_DEFAULT = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_principal)

        findViewById<TextView>(R.id.peso).text = VALOR_DEFAULT.toString()
        findViewById<TextView>(R.id.altura).text = VALOR_DEFAULT.toString()
    }

    fun alterarDados(view: View) {
        val intent = Intent(this, AlterarDados::class.java)

        when(view.id) {
            R.id.alteraPeso -> {
                intent.putExtra("txtEnviado", findViewById<TextView>(R.id.txtPeso).text)
                startActivityForResult(intent, ALTERAR_PESO)
            }
            R.id.alteraAltura -> {
                intent.putExtra("txtEnviado", findViewById<TextView>(R.id.txtAltura).text)
                startActivityForResult(intent, ALTERAR_ALTURA)
            }
        }
    }

    fun calcularIMC(view: View) {
        var peso: Float = findViewById<TextView>(R.id.peso).text.toString().toFloat()
        var altura: Float = findViewById<TextView>(R.id.altura).text.toString().toFloat()

        var alturaConvertida = conveterCmByMetro(altura)

        if (altura == 0F) {
            Toast.makeText(applicationContext, "Erro no cálculo, altura = $alturaConvertida", Toast.LENGTH_SHORT).show()
        } else {
            var imc = realizarCalculoIMC(peso, alturaConvertida)
            mostrarResultado(imc)
        }
    }

    private fun conveterCmByMetro(medida: Float): Float {
        return medida / 100
    }

    private fun realizarCalculoIMC(peso: Float, altura: Float) : Float {
        return peso / (altura * altura)
    }

    private fun mostrarResultado(imc: Float) {

        findViewById<TextView>(R.id.mostraIMC).text = imc.toString()

        if (imc < 16) {
            findViewById<TextView>(R.id.mostraResultado).text = "Magreza grave"
        } else if (imc >=16 && imc < 17) {
            findViewById<TextView>(R.id.mostraResultado).text = "Magreza moderada"
        } else if (imc >=17 && imc < 18.5) {
            findViewById<TextView>(R.id.mostraResultado).text = "Magreza leve"
        } else if (imc >=18.5 && imc < 25) {
            findViewById<TextView>(R.id.mostraResultado).text = "Saudável"
        } else if (imc >=25 && imc < 30) {
            findViewById<TextView>(R.id.mostraResultado).text = "Sobrepeso"
        } else if (imc >=30 && imc < 35) {
            findViewById<TextView>(R.id.mostraResultado).text = "Obesidade Grau I"
        } else if (imc >=35 && imc < 40) {
            findViewById<TextView>(R.id.mostraResultado).text = "Obesidade Grau II (severa)"
        } else {
            findViewById<TextView>(R.id.mostraResultado).text = "Obesidade Grau III (mórbida)"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(resultCode == Activity.RESULT_OK) {

            when(requestCode) {
                ALTERAR_PESO -> findViewById<TextView>(R.id.peso).text = data?.data.toString()
                ALTERAR_ALTURA -> findViewById<TextView>(R.id.altura).text = data?.data.toString()
            }
        }
    }
}
