package br.ufrn.imd.calculadoraimc

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_alterar_dados.*
import kotlinx.android.synthetic.main.activity_alterar_dados.view.*
import kotlin.math.absoluteValue
import kotlin.math.sign

class AlterarDados : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alterar_dados)

        val txtRecebido = intent?.getStringExtra("txtEnviado").toString()
        findViewById<TextView>(R.id.txtDados).text = txtRecebido

    }

    fun salvarDados(view: View) {
        val intent = Intent(this, TelaPrincipal::class.java)

        var dadoAlterado = findViewById<EditText>(R.id.dados).text.toString()

        if (dadoAlterado.isEmpty()) {
            Toast.makeText(applicationContext, "Campo está vazio", Toast.LENGTH_SHORT).show()
        } else {
            intent.setData(Uri.parse(dadoAlterado.toString()))
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
    }

    fun cancelar(view: View) {
        onBackPressed()
    }
}
